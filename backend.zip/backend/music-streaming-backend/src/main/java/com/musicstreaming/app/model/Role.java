package com.musicstreaming.app.model;

public enum Role { USER, ADMIN }
