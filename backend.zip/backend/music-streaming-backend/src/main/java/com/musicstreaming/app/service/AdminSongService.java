package com.musicstreaming.app.service;

import com.musicstreaming.app.model.Song;
import com.musicstreaming.app.repository.SongRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

@Service
public class AdminSongService {

    private static final String AUDIO_DIR = "storage/audio";
    private static final String COVER_DIR = "storage/covers";

    private final SongRepository songRepository;

    public AdminSongService(SongRepository songRepository) {
        this.songRepository = songRepository;
    }

    @Transactional
    public Song uploadSong(
            String title,
            String artist,
            String album,
            String genre,
            int durationSec,
            MultipartFile audioFile,
            MultipartFile coverImage
    ) throws IOException {

        // ensure directories exist
        Files.createDirectories(Paths.get(AUDIO_DIR));
        Files.createDirectories(Paths.get(COVER_DIR));

        // save audio
        String audioFilename = UUID.randomUUID() + "_" + audioFile.getOriginalFilename();
        Path audioPath = Paths.get(AUDIO_DIR, audioFilename);
        Files.copy(audioFile.getInputStream(), audioPath, StandardCopyOption.REPLACE_EXISTING);

        // save cover (optional)
        String coverPathStr = null;
        if (coverImage != null && !coverImage.isEmpty()) {
            String coverFilename = UUID.randomUUID() + "_" + coverImage.getOriginalFilename();
            Path coverPath = Paths.get(COVER_DIR, coverFilename);
            Files.copy(coverImage.getInputStream(), coverPath, StandardCopyOption.REPLACE_EXISTING);
            coverPathStr = coverPath.toString();
        }

        Song song = new Song(
                title,
                artist,
                album,
                genre,
                durationSec,
                audioPath.toString(),
                coverPathStr
        );

        return songRepository.save(song);
    }

    public void deleteSong(UUID id) {
        songRepository.deleteById(id);
    }
}
